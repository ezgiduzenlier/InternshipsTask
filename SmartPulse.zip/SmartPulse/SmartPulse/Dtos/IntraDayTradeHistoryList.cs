﻿using System;
namespace SmartPulse.Dtos
{
    public class IntraDayTradeHistoryList
    {
        public long id { get; set; }
        public DateTime date { get; set; }
        public string conract { get; set; }
        public double price { get; set; }
        public int quantity { get; set; }
    }
}

