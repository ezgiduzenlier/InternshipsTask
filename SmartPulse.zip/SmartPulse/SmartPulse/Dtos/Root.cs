﻿using System;
namespace SmartPulse.Dtos
{
    public class Root
    {
        public string resultCode { get; set; }
        public string resultDescription { get; set; }
        public Body body { get; set; }
    }
}

