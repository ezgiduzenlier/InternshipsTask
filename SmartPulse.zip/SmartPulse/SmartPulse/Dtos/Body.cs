﻿using System;
using static SmartPulse.Controllers.HomeController;

namespace SmartPulse.Dtos
{
    public class Body
    {
        public List<IntraDayTradeHistoryList> intraDayTradeHistoryList { get; set; }
    }
}

