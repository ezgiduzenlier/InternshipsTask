﻿using System;
namespace SmartPulse.Dtos
{
    public class IntraDayDto
    {
        public string Tarih { get; set; }
        public double ToplamIslemTutari { get; set; }
        public double ToplamIslemMiktari { get; set; }
        public double AgirlikliOrtalamaFiyat => ToplamIslemTutari / ToplamIslemMiktari;
    }
}

