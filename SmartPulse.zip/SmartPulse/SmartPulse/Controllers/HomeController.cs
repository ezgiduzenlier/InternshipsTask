﻿using System;
using System.Diagnostics;
using System.Xml;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc;
using SmartPulse.Models;
using SmartPulse.Dtos;


namespace SmartPulse.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private static readonly HttpClient client = new HttpClient();

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public async Task<IActionResult> Index()
    {
        try
        {
            var startDate = DateTime.Now.ToString("yyyy-MM-dd");
            var endDate = DateTime.Now.ToString("yyyy-MM-dd");

            var requestUrl = $"https://seffaflik.epias.com.tr/transparency/service/market/intra-day-trade-history?endDate={endDate}&startDate={startDate}";
            var responseString = await SendRequest(requestUrl); 

            var rootIntraDayTrade = Newtonsoft.Json.JsonConvert.DeserializeObject<Root>(responseString);


            if (rootIntraDayTrade!=null && rootIntraDayTrade.resultDescription == "success")
            {
                var intraDayTradeHistoryList = rootIntraDayTrade.body.intraDayTradeHistoryList.Where(x=>x.conract.Contains("PH")).ToList();
                
                var a = "23060621";

                var groupIntraDays = intraDayTradeHistoryList.GroupBy(x => x.conract).Select(x=>new IntraDayDto
                {
                    ToplamIslemTutari = x.Sum(y=>(y.price*y.quantity)/10),
                    ToplamIslemMiktari = x.Sum(y=>y.quantity/10),
                    Tarih = x.Key.Replace("PH","").Substring(4,2) +"." + x.Key.Replace("PH", "").Substring(2, 2) + ".20" + x.Key.Replace("PH", "").Substring(0, 2) +" "+ x.Key.Replace("PH", "").Substring(6, 2)+":00"
                    
                }).ToList();

                return View(groupIntraDays);
            }

        }
        catch (Exception e)
        {
            _logger.LogError(e.Message);
            Console.WriteLine($"Error :  {e.Message}");
        }

        return View();
    }

    static async Task<string> SendRequest(string url)
    {
        var response = await client.GetAsync(url);

        if (!response.IsSuccessStatusCode)
        {
            Console.WriteLine($"HTTP Error: {response.StatusCode}");
            return string.Empty;
        }

        var responseString = await response.Content.ReadAsStringAsync();

        return responseString;
    }

    public async Task<IActionResult> Privacy()
    {
        return View();
    }
}

